package question07;

public class Question07_03 {
	public static void main(String [] args) {
		int num = 10;
		num = num + 5;
		
		System.out.println("合計数は" + num + "です");
	}

}
