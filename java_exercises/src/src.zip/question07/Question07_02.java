package question07;

public class Question07_02 {
	public static void main(String [] args) {

		
		int sum =10;
		int answer = sum+1;
		 System.out.println("sum に 1 を足すと "+  (answer) +"です");
		
		 System.out.println("sum から 1 を引くと"+  (answer-1) +"です");
		 
		
	}
}
