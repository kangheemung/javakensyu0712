package question07;

public class Question07_01 {
	public static void main(String [] args) {

	
		int num =12;
		int num1 =3;
		int num2 =num/num1;
		 System.out.println("12＋3 は "+  (num+num1) +"です");
		 System.out.println("12-3 は "+  (num-num1) +"です");
		 System.out.println("12×3 は "+  (num*num1) +"です");
		 System.out.println("12÷3 は "+  (num/num1) +"です");
		 System.out.println("12%3の余りは "+  (num2%num1) +"です");
		 
		
	}
}
