package question07;

public class Question07_04 {
	public static void main(String [] args) {
		double dnum = 10.5; 
		int inum1 = (int)dnum;
		//double dnum = (double) inum;
		
		System.out.println("dnum を inum に代入すると" + inum1 + "になります");
	}

}
