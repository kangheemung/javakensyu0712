package question03;

public class Question03_01 {
	public static void main(String[] args) { 
		 System.out.println("ようこそJava へ");
}
	}
