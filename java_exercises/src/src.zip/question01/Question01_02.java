package question01;

public class Question01_02 {
	public static void main(String [] args) {
		System.out.println("こんばんは ");
	}

}
