package question05;

public class Question05_01 {
	public static void main(String[] args) { 
		String str;
		str  ="変数だあ。。。。";
		
		
		 System.out.println(str);
  }

}
//public class Question05_01 {
//	public static void main(String[] args) {
//		byte variableByte;
//		short variableShort;
//		int variableInt;
//		long variableLong;
//		float variableFloat;
//		double variableDouble;
//		char variableChar;
//		boolean variableBoolean;
//	}
//}
