package java_exercises;

public class Question01_01 {
	public static void main(String[]args) {
		System.out.println("こんにちは");
	}

}
