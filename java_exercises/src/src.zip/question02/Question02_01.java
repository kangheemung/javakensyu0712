package question02;

public class Question02_01 {
	public static void main(String [] args ) {
		System.out.println("出力の練習");
		System.out.println("１回目 ");
	}

}
