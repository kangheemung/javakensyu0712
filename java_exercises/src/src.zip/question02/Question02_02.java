package question02;

public class Question02_02 {
	public static void main(String [] args) {
		System.out.print("出力の練習");
		System.out.print("2回目 ");
	}

}
