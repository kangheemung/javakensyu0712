package question04;

public class Question04_02 {
	public static void main(String[] args) { 
		int num =10;
		float f;
			f =	30.5f;
		
		 System.out.println(num +"桁 ");
		 System.out.println(f +"回"); 

  }

}
//public class Question04_02 {
//	public static void main(String[] args) {
//		System.out.print(10);
//		System.out.print('桁' + "\n");
//		System.out.print(30.8);
//		System.out.print('回');
//	}
//}

